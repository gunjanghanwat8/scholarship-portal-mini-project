<?php 
include 'header.php';
$con=mysqli_connect('localhost','root','','ip_project');
$email=$_POST['email'];
$college=$_POST['college'];
$prev=$_POST['prev'];
$marks=$_POST['marks'];
 $filename = $_FILES['result']['name'];

  $filetmpname = $_FILES['result']['tmp_name'];

  $folder = 'results/';
// echo"$email,$college,$prev,$marks,$filename";


  move_uploaded_file($filetmpname, $folder.$filename);
  $query="INSERT INTO `sapp`(`email`, `college`, `lstd`, `marks`, `imgss`) VALUES ('$email','$college','$prev',$marks,'$filename')";
  $run=mysqli_query($con, $query);


$q="select sum(amount) as s from donations";
$que=mysqli_query($con,$q);
$res=mysqli_fetch_assoc($que);
$sum=$res['s'];
if($sum>6000){
  if($run=TRUE)
  	{
      
  		echo"submitted sucessfully ";
      echo"<br>";
      echo"contact here to get your scholarship amount-->> CSGO trust airoli sect-3 near datta meghe college of engineering ";echo'<br>';
      echo"contact number(Gunjan : 8877998422)";
      

  	}
  	else{
  		echo"please try again";
  	}
  }
  else{
    echo"<center><h1>sorry! we don't have funds right now....we will inform you when the fund will again generated thank you!!!!</h1></center>";
    echo"<br><br><br>";
  }

  // include 'foter.php';
 ?>