<!DOCTYPE html>
<html>
<head>
	<title>trust website</title>
	<link rel="stylesheet" type="text/css" href="front.css">
	<style type="text/css">
		*{
	padding:0px;
	margin:0px;
	font-family: calibri;
	/*box-sizing: border-box;*/
	}

body{
	/*background:radial-gradient(grey,silver);*/
	/*background-color:#517693;*/
}
.top{
	width:100%;
	height:100px;
	background-color: transparent;
	/*border: 5px solid black;*/
	/*border-radius: 10px;*/
	box-shadow:inset 0 0 10px #000000;
	/*position: absolute;*/
	/*padding:10px;*/
}
.mar{
	width:90%;
	height:auto;
	margin-left: 5%;
	background-color:transparent;
}
.logo{
	width:20%;
	height:100px;
	background-color:#42C0FB;
	font-size: 50px;
	line-height: 50px;
	text-align: center;
	font-family: calibri;
	float: left;
	color:white;

}

.logo span{

	font-weight: bolder;
	color: white;
	font-size: 65px;
	text-shadow:  0 0 3px #FF0000;;


}
.logo img{
	width:100%;
	height: 100px;
	vertical-align: top;
}
.name{
	width:80%;
	height:100px;
	float: left;
	text-align: center;
	font-size: 30px;
	/*background:linear-gradient(#FF0000,#E80000);*/
	font-family: calibri;
	background-color:#42C0FB;
}
.nav{
	width:100%;
	height: 50px;
	background-color: transparent;
	font-family: calibri;
	/*border-radius: 10px;*/
	/*position:absolute;*/

}
.nav ul li{
	width:25%;
	list-style-type: none;
	float: left;
	text-align: center;
	line-height: 50px;
	font-weight: bold;
	background-color:#262626;
	/*border-radius: 10px;*/
	font-weight: bolder;
	font-size: 20px;
	/*color:silver;*/
	/*position: fixed;*/
}
ul li a{
	display: block;
	text-decoration: none;
	color:silver;


}
ul li a:hover{
		color:#42C0FB;
}

.nav ul li:hover{
	/*background-color:;*/
	cursor: pointer;
	/*border-radius: 10px;*/
	background-color:#191919;

	text-decoration: underline;
}
		
	</style>

</head>
<body>
	<div class="mar">
	
			<div class="top">
			<div class="logo">
				
				<span><i>csgo</i></span><br>
				<p>trust</p>
				
			</div>
			<div id="lo"></div>
			<div class="name">
				<h1>CSGO Trust</h1>
				<h6>airoli sec-15,near datta meghe colleage of engineering.</h6>
				
			</div>
		</div>
		
		<div class="nav">
			<ul>
				<li><a href="front.php" target="_top">home</a></li>
				<li><a href="#gun" target="_top">about us</a></li>
				<li><a href="blog.php" target="_top">blog</a></li>
				<li><a href="#loga" target="_top">login/register</a></li>
			</ul>
		</div>
	</div>


</body>
</html>