<?php include 'header.php' ?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<script type="text/javascript" language="javascript">
		function update() {
			div1.insertAdjacentHTML("AfterEnd", "<p>comment here: <input type='text' value='gunjan'></p>");
		}


	</script>
	<style type="text/css">
		.div
		{
			width:100%;
			background-color: red;
		}
	</style>
</head>
<body>
	<!-- <input type="" name=""> -->
	<h1>upadating part of page</h1>
	<div> <input type="button" value="click here" onclick="update()"></div>


</body>
</html>