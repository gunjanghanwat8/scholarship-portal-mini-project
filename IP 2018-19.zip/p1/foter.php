<!DOCTYPE html>
<html>
<head>
	<title></title>
	<style type="text/css">
		
		.link{
	width:100%;
	height: 150px;
	background-color:#191919;
	float:left;
}
.link h4{
	color:white;
}
.re{
	width:10%;
	height:100px;
	background-color:transparent;
	text-align: center;
	float:left;
}
.re a{
	text-decoration: none;
	color:#42C0FB;
}
.link h4{
	display:inline;
}
hr{
	border-top: 1px dotted;
}
.social
{
	width:80%;
	height:100px;
	 color: white;
	 margin-left:20%;
	 /*text-align: center;*/
	 align-content: center;
	 padding-right: 50px;
	 /*background-color: red;*/
}
.social img
{
	width:50px;
	height: 50px;
	margin-right: 100px;
	/*float: left;*/
}
.social figure
{
	float: left;
}
*{
	padding:0px;
	margin:0px;
	font-family: calibri;
	/*box-sizing: border-box;*/
	}
	</style>
</head>
<body>
	<footer>
	<div class="link" id="thi">
				<h4 >quick links</h4><br>
				<div class="re">
				<a href="front.php">home</a><hr>
				<a href="front.php #gun">about us</a><hr>
				<a href="#">team</a><hr>
				<a href="#">contact us</a>
			</div>
			<div class="social">
				<h3>social media handels</h3>
				<br>
				<figure><img src="w.png">
					<figcaption>8878995114</figcaption></figure>
				<figure>	
				<img src="t.png">
				<figcaption>csgo@twitter.in"</figcaption>
			</figure>
			<figure>
				<img src="f.png" caption="csgo trust">
				<figcaption>CSGO trust</figcaption>
			</figure>
			<figure>
				<img src="instagram-128.png">
					<figcaption>CSGO_trust</figcaption>

			</figure>	
			<figure>
				<img src="m.png">
					<figcaption>csgo1998@gmail.com</figcaption>

			</figure>
			</div>


				
			</div>

</footer>
</body>
</html>