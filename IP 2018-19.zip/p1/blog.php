<!DOCTYPE html>
<html>
<head>
	<title>blog</title>
	<link rel="stylesheet" type="text/css" href="blog.css">
</head>
<body>
<div class="mar">
		<div class="top">
			<div class="logo">
				<span><i>csgo</i></span><br>
				<p>trust</p>
				
			</div>
			<div class="name">
				<h1>csgo trust</h1>
				<h6>airoli sec-15,near datta meghe colleage of engineering.</h6>
				
			</div>
		</div>
		<div class="nav">
			<ul>
				<li><a href="front.php" target="_top">home</a></li>
				<li><a href="front.php #gun" target="_top">about us</a></li>
				<li><a href="blog.php" target="_top">blog</a></li>
				<li><a href="front.php #loga" target="_top">login/register</a></li>
			</ul>
		</div>
		
	<div class="he">
		Blog
		</div>
<br><br>	
		<div class="mess"> click on the image to read the entire blog</div>	

	<div class="bg">
				<div class="a1"> <a href="abc.html" target="_top"><img src="b1.jpg">How to write the scholarship resume..... </a>			</div>
				<div class="a2"><a href="#"><img src="b2.png">how to become the scholarship sponsors</a>	</div>
				<div class="a3"><a href="#"> <img src="b3.jpg"> how to apply for HR scholarships</a>	</div>
	</div>
		
		<!-- <div class="end"></div>	 -->
</div>
</body>
</html>