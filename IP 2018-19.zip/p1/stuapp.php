<!DOCTYPE html>
<html>
<head>
	<title>trust website</title>
	<link rel="stylesheet" type="text/css" href="stuapp.css">
</head>
<body>
	<div class="mar">
	
			<div class="top">
			<div class="logo">
				
				<span><i>csgo</i></span><br>
				<p>trust</p>
				
			</div>
			<div class="name">
				<h1>CSGO Trust</h1>
				<h6>airoli sec-15,near datta meghe colleage of engineering.</h6>
				
			</div>
		</div>
		
		<div class="nav">
			<ul>
				<li><a href="front.php" target="_top">home</a></li>
				<li><a href="front.php #gun" target="_top">about us</a></li>
				<li><a href="blog.html" target="_top">blog</a></li>
				<li><a href="front.php #loga" target="_top">register/login</a></li>
			</ul>
		


		</div>

	<div class="rg">
		<form action="si.php" method="post" enctype="multipart/form-data" autocomplete="off">
			<!-- <fieldset> -->
		<table>
		<h1>scholarship application form</h1><br><hr><br>
		<tr>
			<td><label for="email">username </label></td>
			<td><input type="text" placeholder="student id" name="email"></td></tr>
		<tr>	
			<td>		
			<label for="college name">select college name</label>
			</td>
		<td><input type="text" name="college" placeholder="enter the college name" required="required">
		</select>
		<tr>
			<td><label for="prev">previous year std:</label></td>
			<td><input type="text" name="prev" required="required" placeholder="previous year standard"></td></tr><br><br>
		<tr><td><label for="marks">marks</label></td>
		<td><input type="text" name="marks" placeholder="enter the marks in percentage"></td></tr>

		<tr>
			<td><label for="result" >upload the result</label></td>
			<td><input type="file" name="result"<input name="userfile" type="file" accept="application/pdf, application/vnd.ms-excel" />></td>
		</tr>
		
	</table>
			<button>submit</button>
		<!-- </fieldset> -->
	</form>		<br><br>
	</div>




<br>
	<br>

<?php include 'foter.php' ?>
	</div>

</body></html>
