<!DOCTYPE html>
<html>
<head>
	<title>trust website</title>
	<link rel="stylesheet" type="text/css" href="donation.css">
</head>
<body>
	<div class="mar">
	
			<div class="top">
			<div class="logo">
				
				<span><i>csgo</i></span><br>
				<p>trust</p>
				
			</div>
			<div class="name">
				<h1>CSGO Trust</h1>
				<h6>airoli sec-15,near datta meghe colleage of engineering.</h6>
				
			</div>
		</div>
		
		<div class="nav">
			<ul>
				<li><a href="front.php" target="_top">home</a></li>
				<li><a href="front.php #gun" target="_top">about us</a></li>
				<li><a href="blog.php" target="_top">blog</a></li>
				<li><a href="front.php #loga" target="_top">Register/Login</a></li>
			</ul>
		


		</div>

		<div class="rg">
		<form method="POST" action="d.php" autocomplete="off">
			<!-- <fieldset> -->
			
				<h1>Donate here</h1><br><hr><br>
				
					<label for="email"> Donars username </label>
					<input type="email" placeholder="donar id" name="email" required="required">
		
						<br>	
					<label for="amount">Enter the amount</label>
					<input type="text" name="amount" required="required" placeholder="enter the amount" name="amount"><br>
				
					<label for="camount">Confirm the amount</label>
					<td><input type="text" name="camount" required="required" placeholder="confirm amount" name="camount"><br><br>
				
		
			<button>submit</button>
		<!-- </fieldset> -->
	</form>		
	<br><br>
	</div>
	<br>
	<br>
	<br>
	<?php include'foter.php' ?>
	


</body></html>
