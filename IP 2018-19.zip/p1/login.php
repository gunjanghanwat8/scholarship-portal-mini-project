<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<form method="post" action="lo.php">
	<input type="text" name="name" placeholder="enter name">
	<input type="password" name="password" placeholder="enter the password">
	<button>submit</button>

</form>
</body>
</html>