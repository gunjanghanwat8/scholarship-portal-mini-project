<!DOCTYPE html>
<html>
<head>
	<title>trust website</title>
	<link rel="stylesheet" type="text/css" href="front.css">

</head>
<body>
<?php include 'header.php' ?>
<div class="mar">

	<!-- banner -->
	
		<div class="ban">

			<div class="over">
				
				<div class="slidecover">
					<div class="inner">
						<div class="info1"><br><h2>"Everyone has a purpose in life....a unique gift or special talent to give to others" </h2></div>
						<div class="info1"><br><h2>"Let us make a difference by changing the lives of underprivileged and raising their living standards"</h2></div>
						<div class="info1"><br><h2>"You have always felt sorry for them. Now,you can do something for them"</h2></div>		
					</div>

				</div>

				<!-- <img src="ban.jpg"> -->
			</div>
		</div>


		<div class="bb" >
						<h4>click here to check availability of scolarship   <button ><a href="ca.php">check</a></button></h4>
						
					</div>
				
				
			
			
			
		







	<!-- moto --><div class="moto">
		<h1>Together we can make a Difference</h1>
		</div>





	<!-- login and services -->
				<div class="service">
					<br>
					<h2 >services provided by us</h2><br>
					<ul>
						<li><i>For donation click here &#9758 &nbsp;</i><button><a href="donation.php">click here</a></button></li>
						<li><i>For application of scholarship &#9758 &nbsp;</i><button><a href="stuapp.php">click here</a></button></li>
						<li><i>scolarship information &#9758 &nbsp;</i><button><a href="#"></a>click here</button></li>
						<li>donations list &#9758 &nbsp;
							<button><a href="showdono.php"> click here</a>
							</button></li>

					</ul>
					
				</div>
			<div class="login" id="loga" >
				<div class="ov">
					<span><h2>login details</h2></span><br>
					<form action="l1.php" method="POST" autocomplete="off">
						<label for="userid"> user id:</label><br>
						<input type="text" name="userid" placeholder="login id" required="required"><br>
						<label for="password"> password:</label><br>
						<input type="password" name="password" placeholder="password" required="required"><br><br>
						<button type="submit" value="log in">log in</button>	
					</form><br>
					<a href="sfrom.php">click here for new registration</a>	
					
				</div>
			</div>

			

		
			<div class="vision">
				 
				<div class="v1"> 
						<b>our vision
					</b> 
					<img src="v1.png">
					<p>CSGO works for providing scholarship to the students through students application and also maintains the donor through donor application. Our vision is to interact amongst the donor and students for the well-being of the students with certain criteria. </p>
				</div>
				<div class="v2">
					<b>our mission</b><img src="v2.png"><p>The mission of CSGO is to provide electronic portal to bring the interface between donor and students under the various scheme launched by the  Union Government, State Government and Union territories.</p></div>
				<div class="v3">
					<b>our values</b><img src="v13.png">
					<p>Ensure timely disbursement of Scholarships to students provide a common portal for donor and require candidates for schemes of central and state Governments also to create a transparent database of donors ,and avoid duplication in processing. </p>
				</div>
				
			</div>
			<div class="about" id="gun">
				<div class="adhya">
					
					<img src="con12.png">
				</div>
				<div class="info">
					<br>
					<h2>about us</h2>
					<br>
					<br>
					<p>CSGO is one stop scholarship provided to the students of Mumbai university colleges who are affiliated with backward economic background.</p>
					<p ><h3>Benefits</h3><br>
•	Simplified process for the students:<br>
1.	All information will be available under one umbrella.
2.	Single integrated application<br> 
•	Improved transparency:<br>
1.	System suugests the schemes for which a student is eligible
2.	Duplicates can be reduced to maximum extent<br>
</p>
					
				</div>
				

			</div>

			<!-- vision -->




			<!-- quick link -->
			<div class="link" id="thi">
				<h4 >quick links</h4><br>
				<div class="re">
				<a href="front.php">home</a><hr>
				<a href="front.php #gun">about us</a><hr>
				<a href="#">team</a><hr>
				<a href="#">contact us</a>
			</div>
			<div class="social">
				<h3>social media handels</h3>
				<br>
				<figure><img src="w.png">
					<figcaption>8878995114</figcaption></figure>
				<figure>	
				<img src="t.png">
				<figcaption>csgo@twitter.in"</figcaption>
			</figure>
			<figure>
				<img src="f.png" caption="csgo trust">
				<figcaption>CSGO trust</figcaption>
			</figure>
			<figure>
				<img src="instagram-128.png">
					<figcaption>CSGO_trust</figcaption>

			</figure>	
			<figure>
				<img src="m.png">
					<figcaption>csgo1998@gmail.com</figcaption>

			</figure>
			</div>


				
			</div>





<!-- end -->
<div id="right">site is created by Gunjan,somesh,chinmay under the guidance of Prof Neha Thakur.
This website and its content is copyright of CSGO - ©CSGO_2018. All rights reserved </div>

	</div>	

	<br>
	<br>
</body>
</html>