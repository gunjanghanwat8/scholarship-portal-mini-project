<?php 
$con=mysqli_connect('localhost','root','','ip_project');
$dname=$_POST['dname'];
$email=$_POST['email'];
$password=$_POST['password'];
$cpassword=$_POST['cpassword'];
$date=$_POST['date'];
$addhar=$_POST['addhar'];



$query="INSERT INTO `donar`(`dname`, `email`, `password`, `cpassword`, `date`, `addhar`) VALUES ('$dname','$email','$password','$cpassword','$date','$addhar')";
if ($password==$cpassword) {
	# code...

$run = mysqli_query($con,$query);
if( $run==TRUE )
	echo'<script script language="javascript"> window.alert("successfully registered")</script>';
else
	echo'<script script language="javascript"> window.alert("registration failed")</script>';
}
else
echo '<script script language="javascript"> window.alert("password and confirm password are not same.... please check!!!!!")</script>';





 ?>