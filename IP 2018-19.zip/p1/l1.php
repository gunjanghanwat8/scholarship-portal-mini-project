<?php 

$c=mysqli_connect('localhost','root','','ip_project');
$userid=$_POST['userid'];
$password=$_POST['password'];


$q="select* from student where email = '$userid' and password = '$password'";
$r="select* from donar where email = '$userid' and password='$password'";

$run1=mysqli_query($c,$q);

$run2=mysqli_query($c,$r);
// echo $run1;
// echo$run2;
$row1 = mysqli_fetch_array($run1,MYSQLI_ASSOC);
$active = $row1['active'];
$count1 = mysqli_num_rows($run1);
$row2= mysqli_fetch_array($run2,MYSQLI_ASSOC);
$active = $row2['active'];
$count2= mysqli_num_rows($run2);


if($count1==1 or $count2==1)
{	
	echo'<script script language="javascript">window.alert("login sucessfully")</script>';
	 echo'<script>
	 window.open("front.php","_self")</script>';
	 
	

}

else{
	echo'<script script language="javascript">window.alert("login unsucessful try again!!!")</script>';
	 echo'<script language=javascript>
	 window.open("front.php","_self");
	 </script>';
}
// header("Location:http://localhost/p1/front.php");


 ?>