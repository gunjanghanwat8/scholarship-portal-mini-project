<!DOCTYPEhtml>
<html>
<head>
	<title>trust website</title>
	<link rel="stylesheet" type="text/css" href="header.css">
	<style type="text/css">.for
{
width:50%;
height:auto;
##background-color: red;
margin-left:25%;
border: 2px solid black;
border-radius:10px;
text-align: center;
line-height:50px;
background:linear-gradient(to right,lightblue,white);
box-shadow: 5px 10px 18px #888888;
font-weight: 	bold;
/*text-align: 	left;*/
}
.for button{
padding:10px;
padding-left: 20px;
padding-right: 20px;
background-color:#262626;
color:white;
border-radius:10px;
 
}
label{
	text-align: right;
}
.for table
{
	text-align: center;
	margin-left: 150px;
}
.for button:hover{
background-color: #42C0FB;
cursor:pointer;
color:black;
}
h2{
text-align:center;
color: grey;
font-family:cursive;
 }
.for input{
	text-align:left;
	width:150px;
	margin-left:20px;
	padding: 	5px; 	
	border-radius: 5px;
}</style>

</head>

<body>
	<div class="mar">
	
			<div class="top">
			<div class="logo">
				
				<span><i>csgo</i></span><br>
				<p>trust</p>
				
			</div>
			<div class="name">
				<h1>CSGO Trust</h1>
				<h6>airoli sec-15,near datta meghe colleage of engineering.</h6>
				
			</div>
		</div>
		
		<div class="nav">
			<ul>
				<li><a href="front.php" target="_top">home</a></li>
				<li><a href="front.php #gun" target="_top">about us</a></li>
				<li><a href="blog.php" target="_top">blog</a></li>
				<li><a href="front.php #loga" target="_top">Register/Login</a></li>
			</ul>
		</div>
		<br><br>		
		<h2> Registration form for Donars</h2><br>
	<div class="for">
	<i>enter the details</i><hr>
	<form method="post" action="ds1.php">
<table>

				<tr><td><label for="name">Name:</label></td>
					<td>
					<input type="text" placeholder="enter the name of donar" required="required" name='dname' ><br></td>
				</tr>
				<tr><td>
					<label for="email">Email Id </label></td>
				<td>	<input type="email" placeholder="enter the email id"required="required" name='email'><br></td>
				</tr>
				<tr>
					<td><label for="password"> Create Password</label></td>
					<td><input type="password" placeholder="create a password" name='password'><br></td>
				</tr>
				
				<tr><td>
					<label for="cpassword"> Confirm  Password</label>
				</td>
					<td><input type="password" placeholder="confirm a password"required="required" name='cpassword'><br>	</td></tr>					
				<tr><td>	<label for="date of birth">Date Of Birth</label></td>
					<td><input type="date" placeholder="enter date of birth"required="required" name='date'></td>
				</tr>

					<br>
				<tr><td>	<label for="addhar"> Addhar No</label>
				</td><td>
					<input type="text" name="addhar" placeholder="Enter Addhar number" required="required" name='addhar'></td>
				</tr>
				</table>
			
					<button>Register</button><br>
					<i>already have an account!!!!<a href="front.php #login">click here to login</a></i>
					
		
		
		</form>
		
	
	</div>
	<br>
	<br>
	
</html>