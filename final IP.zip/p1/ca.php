<?php 
$con=mysqli_connect('localhost','root','','ip_project');
$q="select sum(amount) as s from donations";
$query=mysqli_query($con,$q);
$res=mysqli_fetch_assoc($query);
$sum=$res['s'];
if($sum>6000)
{
	echo'<script sciptlanguage="javascript">window.alert("we are ready to help you!!!!!")</script>';
	echo'<script>
	window.open("front.php","_self");</script>';
}
else
{
	echo'<script sciptlanguage="javascript">window.alert("sorry!!!we dont have funds......")</script>';
	echo'<script>
	window.open("front.php","_self");</script>';
}


 ?>