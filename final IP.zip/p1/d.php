<?php 
$conn=mysqli_connect('localhost','root','','ip_project');
$donar=$_POST['email'];
$amount=$_POST['amount'];
$camount=$_POST['camount'];
$query="INSERT INTO `donations`(`email`, `amount`, `camount`) VALUES ('$donar',$amount,$camount)";

$deo="select * from `donar` where email='$donar'";
$gun=mysqli_query($conn,$deo);
$rows = mysqli_num_rows($gun);
// print($rows);
 


// print("$run");

if($rows<=0){
echo"<h1>not registerd user</h1>";
echo"<h3>click on the below link to register as donar<br></h3>";
echo"<a href=ds.php>click here</a>";

}
else{
	$run=mysqli_query($conn,$query);
	echo"donation sucessfull";


}

 ?>