<!DOCTYPE html>
<html>
<head>
	<title>student registeration form</title>
	<link rel="stylesheet" type="text/css" href="sform.css">

</head>
<body>
	<div class="mar">
	
			<div class="top">
			<div class="logo">
				
				<span><i>csgo</i></span><br>
				<p>trust</p>
				
			</div>
			<div class="name">
				<h1>CSGO Trust</h1>
				<h6>airoli sec-15,near datta meghe colleage of engineering.</h6>
				
			</div>
		</div>
		
		<div class="nav">
			<ul>
				<li><a href="home.html" target="_top">home</a></li>
				<li><a href="about.html" target="_top">about us</a></li>
				<li><a href="blog.html" target="_top">blog</a></li>
				<li><a href="contact.html" target="_top">contact us</a></li>
			</ul>
		</div>
<br><br>		
		<h2> registration form for students</h2><br>
	<div class="for">
	<i>enter the details</i><hr>
		<form method="post" action="s1.php" method="post">
					<label for="name">Name:</label>
					<input type="text" placeholder="enter the name of student" required="required" name='sname' ><br>
					<label for="email">Email Id </label>
					<input type="email" placeholder="enter the email id"required="required" name='email'><br>
					<label for="password"> Create Password</label>
					<input type="password" placeholder="create a password" name='password'><br>
					<label for="cpassword"> Confirm  Password</label>
					<input type="password" placeholder="confirm a password"required="required" name='cpassword'><br>						
					<label for="date">Date Of Birth</label>
					<input type="date" placeholder="enter date of birth"required="required" name='date'>
					<br>
					<label for="addhar"> Addhar No</label>
					<input type="text" name="addhar" placeholder="Enter Addhar number" required="required" name='addhar'><br><br>
			
					<button>Register</button><br>
					<i>already have an account!!!!<a href="#">click here to login</a></i>
					
		
		
		</form>
		<a href="ds.php">click here for donar registration</a>
		
	
	</div>	
	
	
	
	
	
	
	
	
	</div>
	